import crypto from 'crypto';

/**
 * SignatureService generates digital signatures for product serials
 * using SHA256 hashing to ensure authenticity and tamper detection.
 */
export class SignatureService {
  /**
   * Generates a digital signature for a product serial.
   * 
   * @param data - The data to sign including productId, serialId, manufacturerId, and carbonFootprint
   * @returns SHA256 hash as a hexadecimal string
   * 
   * Requirements: 9.1, 9.2
   */
  generateSignature(data: {
    productId: string;
    serialId: string;
    manufacturerId: string;
    carbonFootprint: number;
  }): string {
    const { productId, serialId, manufacturerId, carbonFootprint } = data;
    
    // Concatenate all fields to create the signature input
    const signatureInput = `${productId}${serialId}${manufacturerId}${carbonFootprint}`;
    
    // Generate SHA256 hash
    const hash = crypto.createHash('sha256');
    hash.update(signatureInput);
    
    return hash.digest('hex');
  }
}
